module golang.org/x/exp/shiny

go 1.26.0

require (
	dmitri.shuralyov.com/gpu/mtl v0.0.0-20221208032759-85de2813cf6b
	github.com/go-gl/glfw/v3.3/glfw v0.0.0-20231223183121-56fa3ac82ce7
	github.com/jezek/xgb v1.1.1
	golang.org/x/image v0.46.0
	golang.org/x/mobile v0.0.0-20260821190718-4776eadac327
	golang.org/x/sys v0.48.0
)
